This directory contains the scrapy comment crawling project of mongoTV Variety show Who's The Keyman, and the sentiment analysis of nearly 20 thousand commennts.
- scrapy project: mongotv_comments_crawler
- sentiment analysis: pending
