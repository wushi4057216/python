This directory contains font_decode.py for crawling data from shixiseng.com, the data crawled from shixiseng.com(datamining.csv, machinelearning.csv, mlalgorithm.csv), and the codes for analysing the data(数据挖掘、机器学习算法实习生需求分析.ipynb).

- crawler: font_decode.py
- data: datamining.csv, machinelearning.csv, mlalgorithm.csv
- data analysis: 数据挖掘、机器学习算法实习生需求分析.ipynb
